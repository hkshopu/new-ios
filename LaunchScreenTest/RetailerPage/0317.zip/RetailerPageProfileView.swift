//
//  RetailerPagerProfileView.swift
//  HKShopU_ShopFlow
//
//  Created by 林亮宇 on 2021/3/11.
//

import SwiftUI
import UIKit

struct RetailerPageProfileView: View {
    
    @State var image = UIImage()
    
    @State var haveImage = false
    @State var isShowImageLib = false
    
    @State var shopTitle = "我的店舖"
    @State var isShowEditingView = false
    
    @State var rating:Double = 0

    
    
    //TBD in future
    //@State var isShowImageEditingView = false
    //@State var renderedImage = UIImage()
    //@State var saveTriggered = false
    var body: some View {
        ZStack{
            VStack {
                Group{
                    if haveImage {
                        Image(uiImage: image)
                            .clipShape(Circle())
                            
                    }
                    else{
                        Image("PsuedoFoto")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                }
                .onTapGesture {
                    isShowImageLib.toggle()
                }
                HStack{
                    Text(shopTitle)
                        .font(.subheadline)
                        
                    Button(action: {
                        isShowEditingView.toggle()
                    }){
                        Image(systemName: "pencil")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:15)
                            .foregroundColor(Color(hex: 0x979797))
                    }
                }
                HStack(spacing: 3){
                    let intRate = Int(rating)
                    ForEach (0 ..< intRate){ item in
                        Image("Stars_f")
                    }
                    if (rating !=  Double (intRate)){
                        Image("Stars_h")
                        ForEach (intRate + 1  ..< 5 ){ item in
                            Image("Stars")
                        }
                    }else{
                        ForEach (intRate ..< 5 ){ item in
                            Image("Stars")
                        }
                    }
                    
                    Text(String(rating))
                }

//                ImageEditingViewController(saveTriggered: $saveTriggered, renderedImage: self.$renderedImage)
//                    .frame(height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
//                Button(action:{saveTriggered.toggle()}){
//                    Text("save")
//                }
                
                //Image(uiImage: renderedImage)
            }
            
            
        }.fullScreenCover(isPresented: self.$isShowImageLib, content: {
            ImagePicker(originalImage: image, haveImage: self.$haveImage, completionHandler: imageHandler)
        })
        
        
        
    }
    private func imageHandler( image: UIImage?) -> Void{
        
        
        self.image = image ?? UIImage()
        isShowImageLib = false
        
    }
}



struct RetailerPageProfileView_Previews: PreviewProvider {
    static var previews: some View {
        RetailerPageProfileView()
    }
}
